import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import java.awt.GridLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JList;
import javax.swing.JRadioButton;

public class Kupovina extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			Kupovina dialog = new Kupovina();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public Kupovina() {
		setTitle("Kupovina");
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(null);
		contentPanel.setBounds(0, 0, 434, 228);
		contentPanel.setBackground(new Color(67, 17, 6));
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel);
		contentPanel.setLayout(null);
		{
			JPanel imePanel = new JPanel();
			imePanel.setBackground(new Color(67, 17, 6));
			imePanel.setBounds(10, 11, 414, 25);
			contentPanel.add(imePanel);
			imePanel.setLayout(null);
			
			JLabel lblIme = new JLabel("Ime:");
			lblIme.setBounds(10, -2, 42, 25);
			lblIme.setHorizontalAlignment(SwingConstants.LEFT);
			lblIme.setFont(new Font("Tahoma", Font.BOLD, 12));
			lblIme.setForeground(new Color(255, 255, 255));
			imePanel.add(lblIme);
			
			textField = new JTextField();
			textField.setForeground(new Color(67, 17, 6));
			textField.setBounds(70, 1, 100, 20);
			imePanel.add(textField);
			textField.setColumns(10);
		
		
			JPanel prezimePanel = new JPanel();
			prezimePanel.setBackground(new Color(67, 17, 6));
			prezimePanel.setBounds(10, 47, 414, 25);
			contentPanel.add(prezimePanel);
			prezimePanel.setLayout(null);
			
			JLabel lblPrezime = new JLabel("Prezime:");
			lblPrezime.setBounds(10, 7, 51, 15);
			lblPrezime.setFont(new Font("Tahoma", Font.BOLD, 12));
			lblPrezime.setForeground(new Color(255, 255, 255));
			prezimePanel.add(lblPrezime);
			
			textField_1 = new JTextField();
			textField_1.setForeground(new Color(67, 17, 6));
			textField_1.setBounds(70, 1, 100, 20);
			prezimePanel.add(textField_1);
			textField_1.setColumns(10);
		
		
			JPanel adresaPanel = new JPanel();
			adresaPanel.setBackground(new Color(67, 17, 6));
			adresaPanel.setBounds(10, 83, 414, 25);
			contentPanel.add(adresaPanel);
			adresaPanel.setLayout(null);
			
			JLabel lblAdresa = new JLabel("Adresa:");
			lblAdresa.setBounds(10, 7, 46, 15);
			lblAdresa.setFont(new Font("Tahoma", Font.BOLD, 12));
			lblAdresa.setForeground(new Color(255, 255, 255));
			adresaPanel.add(lblAdresa);
			
			textField_2 = new JTextField();
			textField_2.setForeground(new Color(67, 17, 6));
			textField_2.setBounds(70, 1, 100, 20);
			adresaPanel.add(textField_2);
			textField_2.setColumns(10);
		
		
			JPanel telefonPanel = new JPanel();
			telefonPanel.setBackground(new Color(67, 17, 6));
			telefonPanel.setBounds(10, 119, 414, 25);
			contentPanel.add(telefonPanel);
			telefonPanel.setLayout(null);
			
			JLabel lblTelefon = new JLabel("Telefon:");
			lblTelefon.setBounds(10, 7, 49, 15);
			lblTelefon.setFont(new Font("Tahoma", Font.BOLD, 12));
			lblTelefon.setForeground(new Color(255, 255, 255));
			telefonPanel.add(lblTelefon);
			
			textField_3 = new JTextField();
			textField_3.setForeground(new Color(67, 17, 6));
			textField_3.setBounds(70, 1, 100, 20);
			telefonPanel.add(textField_3);
			textField_3.setColumns(10);
		
		
			JPanel placanjePanel = new JPanel();
			placanjePanel.setBackground(new Color(67, 17, 6));
			placanjePanel.setBounds(10, 155, 414, 25);
			contentPanel.add(placanjePanel);
			placanjePanel.setLayout(null);
			
			JLabel lblNewLabel = new JLabel("Nacin placanja:");
			lblNewLabel.setBounds(11, 5, 90, 15);
			lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 12));
			lblNewLabel.setForeground(new Color(255, 255, 255));
			placanjePanel.add(lblNewLabel);
			
			JRadioButton rdbtnPouzecem = new JRadioButton("Pouzecem");
			rdbtnPouzecem.setForeground(new Color(255, 255, 255));
			rdbtnPouzecem.setBackground(new Color(67, 17, 6));
			rdbtnPouzecem.setBounds(107, 2, 99, 23);
			placanjePanel.add(rdbtnPouzecem);
			
			JRadioButton rdbtnKartica = new JRadioButton("Karticom");
			rdbtnKartica.setForeground(new Color(255, 255, 255));
			rdbtnKartica.setBackground(new Color(67, 17, 6));
			rdbtnKartica.setBounds(208, 2, 109, 23);
			placanjePanel.add(rdbtnKartica);
			
			ButtonGroup group = new ButtonGroup();
			group.add(rdbtnPouzecem);
			group.add(rdbtnKartica);
			group.setSelected(null, true);
			group.setSelected(null, false);
		
			JPanel buttonPane = new JPanel();
			buttonPane.setBounds(0, 228, 434, 33);
			buttonPane.setBackground(new Color(67, 17, 6));
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane);
			{
				JButton btnPotvrdi = new JButton("Potvrdi");
				btnPotvrdi.setForeground(new Color(67, 17, 6));
				btnPotvrdi.setActionCommand("OK");
				buttonPane.add(btnPotvrdi);
				getRootPane().setDefaultButton(btnPotvrdi);
				
				btnPotvrdi.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseClicked(MouseEvent arg0) {
						if(textField.getText().equals("") ||textField_1.getText().equals("")||textField_2.getText().equals("")||textField_3.getText().equals("")||group.isSelected(null))
						{
							Kupovina kupovina = new Kupovina();
							kupovina.setVisible(true);
							Potvrda potvrda = new Potvrda();
							potvrda.setVisible(false);
							dispose();
							Uneti uneti = new Uneti();
							uneti.setVisible(true);
						}
						else
						{
							Kupovina kupovina = new Kupovina();
							kupovina.setVisible(false);
							dispose();
							Potvrda potvrda = new Potvrda();
							potvrda.setVisible(true);
							Uneti uneti = new Uneti();
							uneti.setVisible(false);
							dispose();
							
						}
					}
				});
			
				JButton btnOtkazi = new JButton("Otkazi");
				btnOtkazi.setForeground(new Color(67, 17, 6));
				btnOtkazi.setActionCommand("Cancel");
				buttonPane.add(btnOtkazi);
				
				btnOtkazi.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseClicked(MouseEvent e) {
					Pocetna pocetna = new Pocetna();
					pocetna.setVisible(true);
					Kupovina kupovina = new Kupovina();
					kupovina.setVisible(false);
					dispose();
					}});
				
			}}}	
}
			
			
		
	
	
