import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JButton;

public class Kontakt extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Kontakt frame = new Kontakt();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Kontakt() {
		setTitle("Kontakt");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(67, 17, 6));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(67, 17, 6));
		panel.setBounds(0, 0, 434, 91);
		contentPane.add(panel);
		
		JLabel lblTelefon = new JLabel("Telefon: 068-4298923");
		lblTelefon.setFont(new Font("Brush Script MT", Font.BOLD, 30));
		lblTelefon.setForeground(new Color(255, 255, 255));
		lblTelefon.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(lblTelefon);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(67, 17, 6));
		panel_1.setBounds(0, 91, 434, 91);
		contentPane.add(panel_1);
		
		JLabel lblEmail = new JLabel("E-Mail: FenderShop@gmail.com");
		lblEmail.setFont(new Font("Brush Script MT", Font.BOLD, 30));
		lblEmail.setHorizontalAlignment(SwingConstants.CENTER);
		lblEmail.setForeground(new Color(255, 255, 255));
		panel_1.add(lblEmail);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(new Color(67, 17, 6));
		panel_2.setBounds(0, 182, 434, 79);
		contentPane.add(panel_2);
		
		JLabel lblNewLabel = new JLabel("Adresa: Vidovdanska 32, Paracin");
		lblNewLabel.setFont(new Font("Brush Script MT", Font.BOLD, 30));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setForeground(new Color(255, 255, 255));
		panel_2.add(lblNewLabel);
		
		JButton btnNazad = new JButton("Nazad");
		panel_2.add(btnNazad);
		btnNazad.setForeground(new Color(67, 17, 6));
		
		btnNazad.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			Pocetna pocetna = new Pocetna();
			pocetna.setVisible(true);
			Kontakt kontakt = new Kontakt();
			kontakt.setVisible(false);
			dispose();
			}
		});
	}
}
