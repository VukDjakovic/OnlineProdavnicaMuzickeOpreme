import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import java.awt.Rectangle;
import java.awt.Color;
import javax.swing.JTextPane;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.JSeparator;

public class Pocetna extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Pocetna frame = new Pocetna();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Pocetna() {
		setBackground(new Color(86, 22, 10));
		setTitle("Pocetna");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 600, 378);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(86, 22, 10));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblFender = new JLabel("Fender");
		lblFender.setFont(new Font("Brush Script MT", Font.BOLD, 70));
		lblFender.setHorizontalAlignment(SwingConstants.CENTER);
		lblFender.setForeground(new Color(67, 17, 6));
		lblFender.setBounds(320, 0, 204, 68);
		contentPane.add(lblFender);
		
		JSeparator separator = new JSeparator();
		separator.setForeground(new Color(255, 255, 255));
		separator.setBounds(0, 114, 105, 2);
		contentPane.add(separator);
		
		JTextPane txtPnKontakt = new JTextPane();
		txtPnKontakt.setEditable(false);
		txtPnKontakt.setFont(new Font("Brush Script MT", Font.BOLD, 26));
		txtPnKontakt.setForeground(new Color(255, 255, 255));
		txtPnKontakt.setText("Kontakt");
		txtPnKontakt.setBackground(new Color(67, 17, 6));
		txtPnKontakt.setBounds(0, 114, 105, 40);
		contentPane.add(txtPnKontakt);
		
		txtPnKontakt.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			Kontakt kontakt = new Kontakt();
			kontakt.setVisible(true);
			Pocetna pocetna = new Pocetna();
			pocetna.setVisible(false);
			dispose();
			}
			public void mouseEntered(MouseEvent arg0) {
			txtPnKontakt.setForeground(new Color(164, 41, 15));
			}
			public void mouseExited(MouseEvent e) {
			txtPnKontakt.setForeground(Color.WHITE);
			}
			});
		
		JTextPane txtPnKlavijature = new JTextPane();
		txtPnKlavijature.setEditable(false);
		txtPnKlavijature.setFont(new Font("Brush Script MT", Font.BOLD, 23));
		txtPnKlavijature.setForeground(new Color(255, 255, 255));
		txtPnKlavijature.setText("Klavijature");
		txtPnKlavijature.setBackground(new Color(67, 17, 6));
		txtPnKlavijature.setBounds(0, 77, 105, 40);
		contentPane.add(txtPnKlavijature);
		
		txtPnKlavijature.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			Klavijature klavijature = new Klavijature();
			klavijature.setVisible(true);
			Pocetna pocetna = new Pocetna();
			pocetna.setVisible(false);
			dispose();
			}
			public void mouseEntered(MouseEvent arg0) {
			txtPnKlavijature.setForeground(new Color(164, 41, 15));
			}
			public void mouseExited(MouseEvent e) {
			txtPnKlavijature.setForeground(Color.WHITE);
			}
			});
		
		JTextPane txtPnBubnjevi = new JTextPane();
		txtPnBubnjevi.setEditable(false);
		txtPnBubnjevi.setFont(new Font("Brush Script MT", Font.BOLD, 28));
		txtPnBubnjevi.setForeground(new Color(255, 255, 255));
		txtPnBubnjevi.setText("Bubnjevi");
		txtPnBubnjevi.setBackground(new Color(67, 17, 6));
		txtPnBubnjevi.setBounds(0, 40, 105, 40);
		contentPane.add(txtPnBubnjevi);
		
		txtPnBubnjevi.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			Bubnjevi bubnjevi = new Bubnjevi();
			bubnjevi.setVisible(true);
			Pocetna pocetna = new Pocetna();
			pocetna.setVisible(false);
			dispose();
			}
			public void mouseEntered(MouseEvent arg0) {
			txtPnBubnjevi.setForeground(new Color(164, 41, 15));
			}
			public void mouseExited(MouseEvent e) {
			txtPnBubnjevi.setForeground(Color.WHITE);
			}
			});
		
		JTextPane txtPnGitare = new JTextPane();
		txtPnGitare.setEditable(false);
		txtPnGitare.setFont(new Font("Brush Script MT", Font.BOLD, 29));
		txtPnGitare.setText("Gitare");
		txtPnGitare.setForeground(new Color(255, 255, 255));
		txtPnGitare.setBackground(new Color(67, 17, 6));
		txtPnGitare.setBounds(0, 0, 105, 40);
		contentPane.add(txtPnGitare);
		
		txtPnGitare.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			Gitare gitare = new Gitare();
			gitare.setVisible(true);
			Pocetna pocetna = new Pocetna();
			pocetna.setVisible(false);
			dispose();
			}
			public void mouseEntered(MouseEvent arg0) {
			txtPnGitare.setForeground(new Color(164, 41, 15));
			}
			public void mouseExited(MouseEvent e) {
			txtPnGitare.setForeground(Color.WHITE);
			}
			});
		
		JLabel lblHero = new JLabel("");
		lblHero.setIcon(new ImageIcon("E:\\Fakultet\\Projektovanje softvera\\Seminarski rad Vuk Djakovic\\OnlineProdavnicaMuzickeOpreme\\hero.jpg"));
		lblHero.setHorizontalAlignment(SwingConstants.CENTER);
		lblHero.setBounds(0, 0, 584, 339);
		contentPane.add(lblHero);
	}
}
