import java.awt.EventQueue;

import javax.swing.JDialog;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JButton;

public class Uneti extends JDialog {

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Uneti dialog = new Uneti();
					dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
					dialog.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the dialog.
	 */
	public Uneti() {
		getContentPane().setBackground(new Color(67, 17, 6));
		setBounds(100, 100, 450, 300);
		getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Molimo Vas popunite sva polja");
		lblNewLabel.setFont(new Font("Brush Script MT", Font.BOLD, 30));
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setBackground(new Color(67, 17, 6));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(57, 45, 340, 44);
		getContentPane().add(lblNewLabel);
		
		JButton btnOk = new JButton("OK");
		btnOk.setForeground(new Color(67, 17, 6));
		btnOk.setBounds(192, 100, 89, 23);
		getContentPane().add(btnOk);
		
		btnOk.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Uneti uneti = new Uneti();
			uneti.setVisible(false);
			dispose();
			}});

	}

}
