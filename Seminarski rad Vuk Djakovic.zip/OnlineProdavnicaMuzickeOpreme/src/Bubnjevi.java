import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JSeparator;
import javax.swing.ImageIcon;
import javax.swing.JButton;

public class Bubnjevi extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Bubnjevi frame = new Bubnjevi();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Bubnjevi() {
		setTitle("Bubnjevi");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 520, 467);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(67, 17, 6));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblFender = new JLabel("Fender");
		lblFender.setFont(new Font("Brush Script MT", Font.BOLD, 60));
		lblFender.setForeground(new Color(255, 255, 255));
		lblFender.setBounds(165, 11, 200, 58);
		lblFender.setHorizontalAlignment(SwingConstants.CENTER);
		contentPane.add(lblFender);
		
		JSeparator separator = new JSeparator();
		separator.setForeground(new Color(255, 255, 255));
		separator.setBounds(0, 75, 504, 3);
		contentPane.add(separator);
		
		JLabel lblBubnjevi = new JLabel("Bubnjevi u ponudi");
		lblBubnjevi.setFont(new Font("Brush Script MT", Font.BOLD, 35));
		lblBubnjevi.setForeground(new Color(255, 255, 255));
		lblBubnjevi.setHorizontalAlignment(SwingConstants.CENTER);
		lblBubnjevi.setBounds(134, 81, 250, 37);
		contentPane.add(lblBubnjevi);
		
		JLabel lblPearl = new JLabel("");
		lblPearl.setIcon(new ImageIcon("E:\\Fakultet\\Projektovanje softvera\\Seminarski rad Vuk Djakovic\\OnlineProdavnicaMuzickeOpreme\\pearl.jpg"));
		lblPearl.setHorizontalAlignment(SwingConstants.CENTER);
		lblPearl.setBounds(176, 129, 160, 150);
		contentPane.add(lblPearl);
		
		JLabel lblYamaha = new JLabel("");
		lblYamaha.setIcon(new ImageIcon("E:\\Fakultet\\Projektovanje softvera\\Seminarski rad Vuk Djakovic\\OnlineProdavnicaMuzickeOpreme\\yamaha.jpg"));
		lblYamaha.setHorizontalAlignment(SwingConstants.CENTER);
		lblYamaha.setBounds(353, 129, 160, 150);
		contentPane.add(lblYamaha);
		
		JLabel lblPdp = new JLabel("");
		lblPdp.setIcon(new ImageIcon("E:\\Fakultet\\Projektovanje softvera\\Seminarski rad Vuk Djakovic\\OnlineProdavnicaMuzickeOpreme\\pdp.jpg"));
		lblPdp.setBounds(0, 129, 160, 150);
		contentPane.add(lblPdp);
		lblPdp.setHorizontalAlignment(SwingConstants.LEFT);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(67, 17, 6));
		panel.setBounds(10, 315, 121, 113);
		contentPane.add(panel);
		
		JLabel lblPdpCena = new JLabel("Pdp: 1100e   ");
		lblPdpCena.setHorizontalAlignment(SwingConstants.CENTER);
		lblPdpCena.setForeground(new Color(255, 255, 255));
		panel.add(lblPdpCena);
		
		JButton btnKupiPdp = new JButton("Kupi");
		btnKupiPdp.setForeground(new Color(67, 17, 6));
		panel.add(btnKupiPdp);
		
		btnKupiPdp.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			Kupovina kupovina = new Kupovina();
			kupovina.setVisible(true);
			Bubnjevi bubnjevi = new Bubnjevi();
			bubnjevi.setVisible(false);
			dispose();
			}
			});
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(67, 17, 6));
		panel_1.setBounds(197, 315, 121, 113);
		contentPane.add(panel_1);
		
		JLabel lblPearlCena = new JLabel("Pearl: 1270e");
		lblPearlCena.setHorizontalAlignment(SwingConstants.CENTER);
		lblPearlCena.setForeground(new Color(255, 255, 255));
		panel_1.add(lblPearlCena);
		
		JButton btnKupiPearl = new JButton("Kupi");
		btnKupiPearl.setForeground(new Color(67, 17, 6));
		panel_1.add(btnKupiPearl);
		
		btnKupiPearl.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			Kupovina kupovina = new Kupovina();
			kupovina.setVisible(true);
			Bubnjevi bubnjevi = new Bubnjevi();
			bubnjevi.setVisible(false);
			dispose();
			}
			});
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(new Color(67, 17, 6));
		panel_2.setBounds(373, 315, 121, 113);
		contentPane.add(panel_2);
		
		JLabel lblYamahaCena = new JLabel("Yamaha: 2400e");
		lblYamahaCena.setForeground(new Color(255, 255, 255));
		panel_2.add(lblYamahaCena);
		
		JButton btnKupiYamaha = new JButton("Kupi");
		btnKupiYamaha.setForeground(new Color(67, 17, 6));
		panel_2.add(btnKupiYamaha);
		
		btnKupiYamaha.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			Kupovina kupovina = new Kupovina();
			kupovina.setVisible(true);
			Bubnjevi bubnjevi = new Bubnjevi();
			bubnjevi.setVisible(false);
			dispose();
			}
			});
		
		JButton btnNazad = new JButton("Nazad");
		btnNazad.setForeground(new Color(67, 17, 6));
		btnNazad.setBounds(405, 11, 89, 23);
		contentPane.add(btnNazad);
		
		btnNazad.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			Pocetna pocetna = new Pocetna();
			pocetna.setVisible(true);
			Bubnjevi bubnjevi = new Bubnjevi();
			bubnjevi.setVisible(false);
			dispose();
			}
		});
	}
}
