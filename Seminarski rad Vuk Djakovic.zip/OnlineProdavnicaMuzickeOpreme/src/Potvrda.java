import java.awt.EventQueue;

import javax.swing.JDialog;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JPanel;

public class Potvrda extends JDialog {

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Potvrda dialog = new Potvrda();
					dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
					dialog.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the dialog.
	 */
	public Potvrda() {
		getContentPane().setBackground(new Color(67, 17, 6));
		getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Hvala Vam na kupovini");
		lblNewLabel.setBounds(0, 0, 434, 142);
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setFont(new Font("Brush Script MT", Font.BOLD, 30));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		getContentPane().add(lblNewLabel);
		
		JButton btnOk = new JButton("OK");
		btnOk.setForeground(new Color(67, 17, 6));
		btnOk.setBounds(169, 131, 89, 23);
		getContentPane().add(btnOk);
		setBounds(100, 100, 450, 300);
		
		btnOk.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			Pocetna pocetna = new Pocetna();
			pocetna.setVisible(true);
			Potvrda potvrda = new Potvrda();
			potvrda.setVisible(false);
			dispose();
			}
			});

	}
}
