import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JSeparator;
import javax.swing.ImageIcon;
import javax.swing.JButton;

public class Klavijature extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Gitare frame = new Gitare();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Klavijature() {
		setTitle("Klavijature");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 520, 467);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(67, 17, 6));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblFender = new JLabel("Fender");
		lblFender.setFont(new Font("Brush Script MT", Font.BOLD, 60));
		lblFender.setForeground(new Color(255, 255, 255));
		lblFender.setBounds(165, 11, 200, 58);
		lblFender.setHorizontalAlignment(SwingConstants.CENTER);
		contentPane.add(lblFender);
		
		JSeparator separator = new JSeparator();
		separator.setForeground(new Color(255, 255, 255));
		separator.setBounds(0, 75, 504, 3);
		contentPane.add(separator);
		
		JLabel lblKlavijature = new JLabel("Klavijature u ponudi");
		lblKlavijature.setFont(new Font("Brush Script MT", Font.BOLD, 35));
		lblKlavijature.setForeground(new Color(255, 255, 255));
		lblKlavijature.setHorizontalAlignment(SwingConstants.CENTER);
		lblKlavijature.setBounds(134, 81, 269, 37);
		contentPane.add(lblKlavijature);
		
		JLabel lblCasio = new JLabel("");
		lblCasio.setIcon(new ImageIcon("E:\\Fakultet\\Projektovanje softvera\\Seminarski rad Vuk Djakovic\\OnlineProdavnicaMuzickeOpreme\\casio.jpg"));
		lblCasio.setHorizontalAlignment(SwingConstants.CENTER);
		lblCasio.setBounds(165, 129, 175, 150);
		contentPane.add(lblCasio);
		
		JLabel lblAlesis = new JLabel("");
		lblAlesis.setIcon(new ImageIcon("E:\\Fakultet\\Projektovanje softvera\\Seminarski rad Vuk Djakovic\\OnlineProdavnicaMuzickeOpreme\\alesis.jpg"));
		lblAlesis.setHorizontalAlignment(SwingConstants.CENTER);
		lblAlesis.setBounds(340, 129, 165, 150);
		contentPane.add(lblAlesis);
		
		JLabel lblKorg = new JLabel("");
		lblKorg.setIcon(new ImageIcon("E:\\Fakultet\\Projektovanje softvera\\Seminarski rad Vuk Djakovic\\OnlineProdavnicaMuzickeOpreme\\korgg.jpg"));
		lblKorg.setBounds(0, 129, 165, 150);
		contentPane.add(lblKorg);
		lblKorg.setHorizontalAlignment(SwingConstants.LEFT);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(67, 17, 6));
		panel.setBounds(10, 315, 121, 113);
		contentPane.add(panel);
		
		JLabel lblKorgCena = new JLabel("Korg: 2000e");
		lblKorgCena.setHorizontalAlignment(SwingConstants.CENTER);
		lblKorgCena.setForeground(new Color(255, 255, 255));
		panel.add(lblKorgCena);
		
		JButton btnKupiKorg = new JButton("Kupi");
		btnKupiKorg.setForeground(new Color(67, 17, 6));
		panel.add(btnKupiKorg);
		
		btnKupiKorg.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			Kupovina kupovina = new Kupovina();
			kupovina.setVisible(true);
			Klavijature klavijature = new Klavijature();
			klavijature.setVisible(false);
			dispose();
			}
			});
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(67, 17, 6));
		panel_1.setBounds(197, 315, 121, 113);
		contentPane.add(panel_1);
		
		JLabel lblCasioCena = new JLabel("Casio: 1200e");
		lblCasioCena.setHorizontalAlignment(SwingConstants.CENTER);
		lblCasioCena.setForeground(new Color(255, 255, 255));
		panel_1.add(lblCasioCena);
		
		JButton btnKupiCasio = new JButton("Kupi");
		btnKupiCasio.setForeground(new Color(67, 17, 6));
		panel_1.add(btnKupiCasio);
		
		btnKupiCasio.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			Kupovina kupovina = new Kupovina();
			kupovina.setVisible(true);
			Klavijature klavijature = new Klavijature();
			klavijature.setVisible(false);
			dispose();
			}
			});
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(new Color(67, 17, 6));
		panel_2.setBounds(373, 315, 121, 113);
		contentPane.add(panel_2);
		
		JLabel lblAlesisCena = new JLabel("Alesis: 500e ");
		lblAlesisCena.setHorizontalAlignment(SwingConstants.CENTER);
		lblAlesisCena.setForeground(new Color(255, 255, 255));
		panel_2.add(lblAlesisCena);
		
		JButton btnKupiAlesis = new JButton("Kupi");
		btnKupiAlesis.setForeground(new Color(67, 17, 6));
		panel_2.add(btnKupiAlesis);
		
		btnKupiAlesis.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			Kupovina kupovina = new Kupovina();
			kupovina.setVisible(true);
			Klavijature klavijature = new Klavijature();
			klavijature.setVisible(false);
			dispose();
			}
			});
		
		JButton btnNazad = new JButton("Nazad");
		btnNazad.setForeground(new Color(67, 17, 6));
		btnNazad.setBounds(405, 11, 89, 23);
		contentPane.add(btnNazad);
		
		btnNazad.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			Pocetna pocetna = new Pocetna();
			pocetna.setVisible(true);
			Klavijature klavijature = new Klavijature();
			klavijature.setVisible(false);
			dispose();
			}
		});
	}
}
