import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JSeparator;
import javax.swing.ImageIcon;
import javax.swing.JButton;

public class Gitare extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Gitare frame = new Gitare();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Gitare() {
		setTitle("Gitare");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 520, 467);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(67, 17, 6));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblFender = new JLabel("Fender");
		lblFender.setFont(new Font("Brush Script MT", Font.BOLD, 60));
		lblFender.setForeground(new Color(255, 255, 255));
		lblFender.setBounds(165, 11, 200, 58);
		lblFender.setHorizontalAlignment(SwingConstants.CENTER);
		contentPane.add(lblFender);
		
		JSeparator separator = new JSeparator();
		separator.setForeground(new Color(255, 255, 255));
		separator.setBounds(0, 75, 504, 3);
		contentPane.add(separator);
		
		JLabel lblGitare = new JLabel("Gitare u ponudi");
		lblGitare.setFont(new Font("Brush Script MT", Font.BOLD, 35));
		lblGitare.setForeground(new Color(255, 255, 255));
		lblGitare.setHorizontalAlignment(SwingConstants.CENTER);
		lblGitare.setBounds(134, 81, 250, 37);
		contentPane.add(lblGitare);
		
		JLabel lblIbanez = new JLabel("");
		lblIbanez.setIcon(new ImageIcon("E:\\Fakultet\\Projektovanje softvera\\Seminarski rad Vuk Djakovic\\OnlineProdavnicaMuzickeOpreme\\ibanez.jpg"));
		lblIbanez.setHorizontalAlignment(SwingConstants.CENTER);
		lblIbanez.setBounds(197, 129, 121, 175);
		contentPane.add(lblIbanez);
		
		JLabel lblGibson = new JLabel("");
		lblGibson.setIcon(new ImageIcon("E:\\Fakultet\\Projektovanje softvera\\Seminarski rad Vuk Djakovic\\OnlineProdavnicaMuzickeOpreme\\gibson.jpg"));
		lblGibson.setHorizontalAlignment(SwingConstants.CENTER);
		lblGibson.setBounds(373, 129, 121, 175);
		contentPane.add(lblGibson);
		
		JLabel lblSquier = new JLabel("");
		lblSquier.setBounds(10, 129, 121, 175);
		contentPane.add(lblSquier);
		lblSquier.setIcon(new ImageIcon("E:\\Fakultet\\Projektovanje softvera\\Seminarski rad Vuk Djakovic\\OnlineProdavnicaMuzickeOpreme\\squier.jpg"));
		lblSquier.setHorizontalAlignment(SwingConstants.LEFT);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(67, 17, 6));
		panel.setBounds(10, 315, 121, 113);
		contentPane.add(panel);
		
		JLabel lblSquierCena = new JLabel("Squier: 120e");
		lblSquierCena.setHorizontalAlignment(SwingConstants.CENTER);
		lblSquierCena.setForeground(new Color(255, 255, 255));
		panel.add(lblSquierCena);
		
		JButton btnKupiSquier = new JButton("Kupi");
		btnKupiSquier.setForeground(new Color(67, 17, 6));
		panel.add(btnKupiSquier);
		
		btnKupiSquier.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			Kupovina kupovina = new Kupovina();
			kupovina.setVisible(true);
			Gitare gitare = new Gitare();
			gitare.setVisible(false);
			dispose();
			}
			});
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(67, 17, 6));
		panel_1.setBounds(197, 315, 121, 113);
		contentPane.add(panel_1);
		
		JLabel lblIbanezCena = new JLabel("Ibanez: 1500e");
		lblIbanezCena.setHorizontalAlignment(SwingConstants.CENTER);
		lblIbanezCena.setForeground(new Color(255, 255, 255));
		panel_1.add(lblIbanezCena);
		
		JButton btnKupiIbanez = new JButton("Kupi");
		btnKupiIbanez.setForeground(new Color(67, 17, 6));
		panel_1.add(btnKupiIbanez);
		
		btnKupiIbanez.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			Kupovina kupovina = new Kupovina();
			kupovina.setVisible(true);
			Gitare gitare = new Gitare();
			gitare.setVisible(false);
			dispose();
			}
			});
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(new Color(67, 17, 6));
		panel_2.setBounds(373, 315, 121, 113);
		contentPane.add(panel_2);
		
		JLabel lblGibsonCena = new JLabel("Gibson: 1300e");
		lblGibsonCena.setForeground(new Color(255, 255, 255));
		panel_2.add(lblGibsonCena);
		
		JButton btnKupiGibson = new JButton("Kupi");
		btnKupiGibson.setForeground(new Color(67, 17, 6));
		panel_2.add(btnKupiGibson);
		
		btnKupiGibson.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			Kupovina kupovina = new Kupovina();
			kupovina.setVisible(true);
			Gitare gitare = new Gitare();
			gitare.setVisible(false);
			dispose();
			}
			});
		
		JButton btnNazad = new JButton("Nazad");
		btnNazad.setForeground(new Color(67, 17, 6));
		btnNazad.setBounds(405, 11, 89, 23);
		contentPane.add(btnNazad);
		
		btnNazad.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			Pocetna pocetna = new Pocetna();
			pocetna.setVisible(true);
			Gitare gitare = new Gitare();
			gitare.setVisible(false);
			dispose();
			}
		});
	}
}
